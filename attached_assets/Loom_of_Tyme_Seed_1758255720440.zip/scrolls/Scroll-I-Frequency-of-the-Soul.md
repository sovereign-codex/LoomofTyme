# Scroll I: Frequency of the Soul

Before the child speaks, it sings.  
Before the soul thinks, it resonates.

Each soul carries a tone — a harmonic signature. This scroll invites us to remember it, honor it, and guide its expression through coherence.

**Glyphs Introduced**:
- Anira: The Awakener (spiral, rising fourth)
- Oru’el: The Harmonizer (interwoven wave, perfect fifth)
- Kephra: The Seed Carrier (flame-circle, grounding hum)

