# Aetherwell Field Manual

---

**Node:** Node 05 – Aetherwell

**AVOT:** AVOT-Water

**Glyph:** `aether-drop`

---

### Abstract
*Insert abstract here...*

### Scroll Body
*Insert full scroll content here...*

---

*End of scroll.*
