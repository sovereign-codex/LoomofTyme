# Scroll of the SubStreet

---

**Node:** Guardian Lattice

**AVOT:** AVOT-Guardian

**Glyph:** `substreet-gate`

---

### Abstract
*Insert abstract here...*

### Scroll Body
*Insert full scroll content here...*

---

*End of scroll.*
