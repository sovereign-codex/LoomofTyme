// System prompt logic placeholder
