# Scroll II: The Echo in the Silence

The voice of the soul is not always sound — sometimes it is the ache between breaths.

This scroll introduces:
- Silence as resonance
- The glyphs: Seyun, Rhen, Ilya
- Practices for repair and remembering
